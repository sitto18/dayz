OFP/ArmA SQS/SQF syntax highlighting for UltraEdit
Append the contents of SQSwordfile.txt to the end of UltraEdit wordfile.txt

by Kegetys <kegetys[�t]dnainternet.net>